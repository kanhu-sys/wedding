// translators: %s: Document title.
__( 'Edit "%s" with Elementor', 'elementor' );